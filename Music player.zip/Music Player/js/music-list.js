// To add more song, just copy the following code and paste inside the array

//   {
//     name: "Here is the music name",
//     artist: "Here is the artist name",
//     img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
//     src: "music name here - remember img must be in .mp3 formate and it's inside the songs folder of this project folder"
//   }

//paste it inside the array as more as you want music then you don't need to do any other thing

let allMusic = [
  {
    name: "Woh",
    artist:"Badshah",
    img: "Woh",
    src: "Woh"
  },
  {
    name: "Phir aur kya chaiye",
    artist: "Arijit singh",
    img: "Phir aur kya chaiye",
    src: "Phir aur kya chaiye"
  },
  {
    name: "Tu Jeene Ki Wajah",
    artist: "Rishi singh",
    img: "Tu Jeene Ki Wajah",
    src: "Tu Jeene Ki Wajah"
  },
  {
    name: "Moonrise",
    artist: "Atif aslam",
    img: "Moonrise",
    src: "Moonrise"
  },

];